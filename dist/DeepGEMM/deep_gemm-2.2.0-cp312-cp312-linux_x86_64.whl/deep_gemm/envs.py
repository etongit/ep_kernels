# Pre-installed environment variables
persistent_envs = dict()
